from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('emails.urls')),
    path('api/', include('emails.urls')),
]
